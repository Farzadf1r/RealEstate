# real-estate-management

docker-compose build
docker-compose up