package com.houselogiq;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

//@SpringBootTest
class RealEstateManagementApplicationTests {

//	@Test
	void contextLoads() {
	}

}
