package com.houselogiq.data.model;

public enum RoleType {
    AGENT,
    CLIENT,
    ADMIN,
    ANONYMOUS
}
