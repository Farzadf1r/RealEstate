package com.houselogiq.data.model;

public enum StatusType {
    VALID,
    INVALID,
    UNKNOWN
}
