package com.houselogic.customerapp

import io.flutter.embedding.android.FlutterActivity


class MainActivity: FlutterActivity() {


}
