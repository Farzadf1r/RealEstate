

class UnexpectedResponseCode implements Exception
{
  final String message;
  UnexpectedResponseCode([this.message]);
}