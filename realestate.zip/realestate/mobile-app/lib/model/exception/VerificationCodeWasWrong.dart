

class VerificationCodeWasWrong implements Exception
{

}