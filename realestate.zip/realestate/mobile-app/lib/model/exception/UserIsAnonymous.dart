

class UserIsAnonymous implements Exception
{

}