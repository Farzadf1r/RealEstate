

class ConnectionToBackendFailed implements Exception
{

}