

class NoSuchUserWithGivenMobile implements Exception
{

}