
class CustomerSearchFilter
{
  String specificAgentId = "";

  CustomerSearchFilter({this.specificAgentId=""});

}