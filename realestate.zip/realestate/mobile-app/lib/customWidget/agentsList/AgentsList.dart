import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:realestate_app/customWidget/agentsList/AgentsListItem.dart';
import 'package:realestate_app/customWidget/agentsList/AgentsPagedContentModel.dart';
import 'package:realestate_app/customWidget/blocModelProvider/ModelProvider.dart';
import 'package:realestate_app/customWidget/pagedListView/PagedListView.dart';
import 'package:realestate_app/model/entity/Agent.dart';



class AgentsList extends StatelessWidget {

  static const _ContentDescription = "AgentsList";

  final void Function(Agent) agentSelected;

  AgentsList({this.agentSelected})
  {
    ModelProvider.instance.provideThisOneTimeAlternativeIfCreatorCouldNotCreate(_ContentDescription, ()=>AgentsPagedContentModel(10, _ContentDescription));
  }

  build(BuildContext context) {
    return PagedListView<Agent>(
        _ContentDescription,
        (context, overallPosition, Agent agent) => Padding(
              padding: const EdgeInsets.all(8.0),
              child: AgentsListItem(agent,agentSelected: agentSelected,),
            ));
  }
}
