import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:realestate_app/customWidget/general/FutureWidget.dart';
import 'package:realestate_app/customWidget/general/PercentageWidget.dart';
import 'package:realestate_app/customWidget/general/Utils.dart';
import 'package:realestate_app/model/ServerGateway.dart';
import 'package:realestate_app/model/entity/Agent.dart';

class AgentsListItem extends StatelessWidget {
  final Agent agent;
  final void Function(Agent) agentSelected;
  AgentsListItem(this.agent,{this.agentSelected}) : super();

  build(context){

    if(agentSelected==null)
      return _createContent(context);
    else
      return FlatButton(onPressed: ()=>agentSelected(agent), child: _createContent(context));
  }

  Container _createContent(BuildContext context) {
    return Container(
  height: percentageOfDeviceHeight(context, 0.15),
  child: Row(
    mainAxisSize: MainAxisSize.max,
    crossAxisAlignment: CrossAxisAlignment.center,
    children: [
      SizedBox(width: 5),
      createProfilePic(),
      SizedBox(width: 15),

      createAgentName(),
    ],
  ),
);
  }


  createProfilePic() {
    return FutureWidget(initialLoadingBoxWidth: 10,initialLoadingBoxHeight: 10,
      future:ServerGateway.instance().loadImage(agent.photoUrl),
      errorBuilder: (context,exception)=>PercentageWidget(
        widthRatio: "0.5ph",
        heightRatio: "0.5ph",
        child: ClipOval(
          child: Placeholder()
        ),
      ),
      builder: (context, profilePicFile) => PercentageWidget(
        widthRatio: "0.65ph",
        heightRatio: "0.65ph",
        child: ClipOval(
          child: Image.file(
            profilePicFile,
            fit: BoxFit.cover,
          ),
        ),
      ),
    );
  }

  createAgentName() => Column(
    mainAxisSize: MainAxisSize.min,
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      Text(
        agent.fullNameIfNotNullOrMobileOrEmail,
        style: TextStyle(
            color: Color(0xff000000),
            fontSize: 14,
            fontFamily: "Halvetica",
            fontWeight: FontWeight.w100),
      ),
      SizedBox(
        height: 5,
      ),
      Text(
        "Customers Being Represented : ${agent.representingCustomersCount}",
        style: TextStyle(
            color: Color(0xff868686),
            fontSize: 13,
            fontFamily: "Halvetica",
            fontWeight: FontWeight.w100),
      ),
      SizedBox(
        height: 5,
      ),
      Text(
        "Invitations Count : ${agent.invitationsCount}",
        style: TextStyle(
            color: Color(0xff868686),
            fontSize: 13,
            fontFamily: "Halvetica",
            fontWeight: FontWeight.w100),
      )
    ],
  );


}
