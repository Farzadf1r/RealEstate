


import 'package:realestate_app/customWidget/map/GeoMarker.dart';
import 'package:realestate_app/customWidget/map/GeoPoint.dart';

double toDoubleWithFractionDigits(double number,int fractionDigits)
{
  return double.parse((number.toStringAsFixed(fractionDigits)));
}

class GeoTile{

  GeoPoint get bottomLeft => _bottomLeft;
  GeoPoint get topRight => _topRight;
  GeoPoint _bottomLeft;
  GeoPoint _topRight;
  String _id;

  List<GeoMarker> _markers;
  bool get hasData => _markers !=null;

  List<GeoMarker> get data{
    if(!hasData)
      throw Exception("does not have data!");

    return _markers;
  }
  
  double get tileWidth => (topRight.longitude - bottomLeft.longitude).abs();
  double get tileHeight => (topRight.latitude - bottomLeft.latitude).abs();
  
  String get id => _id;

  GeoTile(GeoPoint bl,GeoPoint tr)
  {
    _bottomLeft = GeoPoint(toDoubleWithFractionDigits(bl.longitude,1), toDoubleWithFractionDigits(bl.latitude,1));
    _topRight   = GeoPoint(toDoubleWithFractionDigits(tr.longitude,1), toDoubleWithFractionDigits(tr.latitude,1));
    _id = "${bottomLeft.longitude.toStringAsFixed(1)}_${bottomLeft.latitude.toStringAsFixed(1)}";
  }



  void setData(List<GeoMarker> markers)
  {
    if(markers==null)
      throw Exception("data cannot be null!");

    _markers = markers;
  }

  void removeData()
  {
    _markers = null;
  }

  bool contains(GeoPoint point) {
    return point.longitude >= bottomLeft.longitude
        && point.latitude >= bottomLeft.latitude
        && point.longitude < topRight.longitude
        && point.latitude < topRight.latitude;
  }

  toString() =>'{bl: $bottomLeft, tr: $topRight, }';
}