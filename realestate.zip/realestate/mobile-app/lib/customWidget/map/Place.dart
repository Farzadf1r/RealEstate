

import 'package:google_maps_cluster_manager/google_maps_cluster_manager.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:meta/meta.dart';

class Place with ClusterItem {
  final String name;
  final LatLng latLng;
  final bool isClosed;

  Place({@required this.name, this.isClosed = false, @required this.latLng});

  @override
  LatLng get location => latLng;

  @override
  String toString() {
    return 'Place $name (closed : $isClosed)';
  }
}
