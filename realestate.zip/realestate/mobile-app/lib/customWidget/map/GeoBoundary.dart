
import 'dart:math';

import 'package:realestate_app/customWidget/map/GeoPoint.dart';

import 'GeoTile.dart';

class GeoBoundary
{
  GeoPoint _bottomLeft;
  GeoPoint _topRight;
  GeoPoint get bottomLeft => _bottomLeft;
  GeoPoint get topRight => _topRight;

  final double tileWidth;
  final double tileHeight;

  double get width => (topRight.longitude - bottomLeft.longitude).abs();
  double get height => (topRight.latitude - bottomLeft.latitude).abs();
  double get minLineWidthWithingBoundary => min(width, height);

  GeoTile  _bottomLeftTile;
  GeoTile  _topRightTile;
  GeoTile get bottomLeftTile => _bottomLeftTile;
  GeoTile get topRightTile => _topRightTile;

  GeoBoundary(GeoPoint bl,GeoPoint tr,this.tileWidth,this.tileHeight , {GeoBoundary acceptableRange})
  {
    if(acceptableRange == null)
    {
      _bottomLeft = bl;
      _topRight = tr;
    }else
    {
      _bottomLeft = GeoPoint( max(bl.longitude , acceptableRange.bottomLeft.longitude)
        ,max(bl.latitude,acceptableRange.bottomLeft.latitude));

      _topRight = GeoPoint( min(tr.longitude,acceptableRange.topRight.longitude)
        ,min(tr.latitude,acceptableRange.topRight.latitude));
    }

    _bottomLeftTile = _calculateBottomLeftTile();
    _topRightTile = _calculateTopRightTile();
  }

  GeoBoundary withAddedMargin(double percentage, {GeoBoundary acceptableRange})
  {
    double marginWidth = (bottomLeft.longitude - topRight.longitude).abs() * percentage;
    double marginHeight = (bottomLeft.latitude - topRight.latitude).abs() * percentage;

    return GeoBoundary(
        GeoPoint(bottomLeft.longitude-marginWidth,bottomLeft.latitude-marginHeight)
        ,GeoPoint(topRight.longitude + marginWidth,topRight.latitude + marginHeight)
        , tileWidth, tileHeight,acceptableRange: acceptableRange);
  }

  GeoTile _calculateTopRightTile() {
    double tileBLLongitude = (topRight.longitude/tileWidth).floor() * tileWidth;
    double tileBLLatitude = (topRight.latitude/tileHeight).floor() * tileHeight;
    double tileTRLongitude = (topRight.longitude/tileWidth).ceil() * tileWidth;
    double tileTRLatitude = (topRight.latitude/tileHeight).ceil() * tileHeight;

    return GeoTile(GeoPoint(tileBLLongitude, tileBLLatitude),GeoPoint(tileTRLongitude,tileTRLatitude));
  }

  GeoTile _calculateBottomLeftTile() {
    double tileBLLongitude = (bottomLeft.longitude/tileWidth).floor() * tileWidth;
    double tileBLLatitude = (bottomLeft.latitude/tileHeight).floor() * tileHeight;
    double tileTRLongitude = (bottomLeft.longitude/tileWidth).ceil() * tileWidth;
    double tileTRLatitude = (bottomLeft.latitude/tileHeight).ceil() * tileHeight;

    return GeoTile(GeoPoint(tileBLLongitude, tileBLLatitude),GeoPoint(tileTRLongitude,tileTRLatitude));
  }

  bool differFromAtLeast(GeoBoundary boundary, double difference) {
    
    var blLonMove = (bottomLeft.longitude - boundary.bottomLeft.longitude).abs();
    var blLatMove = (bottomLeft.latitude  - boundary.bottomLeft.latitude).abs();
    var trLonMove = (topRight.longitude   - boundary.topRight.longitude).abs();
    var trLatMove = (topRight.latitude    - boundary.topRight.latitude).abs();

    if(blLatMove <= difference && blLonMove<=difference && trLatMove<=difference && trLonMove<=difference)
      return false;
    
    return true;
  }

  bool contains(GeoPoint point) {
    return point.longitude >= bottomLeft.longitude
        && point.latitude >= bottomLeft.latitude
        && point.longitude < topRight.longitude
        && point.latitude < topRight.latitude;
  }



  Iterable<GeoTile> get iterableOverAllTilesWithinInclusiveInclusive {
    return _TileIterableWithinBoundary(this,tileWidth,tileHeight);
  }
}



class _TileIterableWithinBoundary extends Iterable<GeoTile>
{
  final GeoBoundary _boundary;
  final double _tileWidth;
  final double _tileHeight;
  Iterator<GeoTile> get iterator => _TileIteratorWithinBoundary(_boundary,_tileWidth,_tileHeight);
  _TileIterableWithinBoundary(this._boundary,this._tileWidth,this._tileHeight);
}

class _TileIteratorWithinBoundary extends Iterator<GeoTile>
{
  final GeoBoundary _boundary;
  final double _tileWidth;
  final double _tileHeight;
  bool _isInitialized = false;
  int _x ,_y;

  _TileIteratorWithinBoundary(this._boundary,this._tileWidth,this._tileHeight)
  {
    _resetX();
    _resetY();
  }

  _resetX()
  {
    _x = toDoubleWithFractionDigits(_boundary.bottomLeftTile.bottomLeft.longitude / _tileWidth,1).toInt();
  }

  _resetY()
  {
    _y = toDoubleWithFractionDigits(_boundary.bottomLeftTile.bottomLeft.latitude / _tileHeight,1).toInt();
  }

  bool _xNeedsRestart()
  {
    return _x > toDoubleWithFractionDigits(_boundary.topRightTile.bottomLeft.longitude / _tileWidth,1);
  }

  bool _yNeedsRestart()
  {
    return _y > toDoubleWithFractionDigits(_boundary.topRightTile.bottomLeft.latitude / _tileHeight,1);
  }

  _advanceX()
  {
    _x++;
  }

  _advanceY()
  {
    _y++;
  }


  GeoTile get current{

    if(!_isInitialized || _xNeedsRestart())
      throw Exception("you cannot call current before initialization or past last element!");

    double tileBLLongitude = _x * _tileWidth;
    double tileBLLatitude =  _y * _tileHeight;
    double tileTRLongitude = (_x+1) * _tileWidth;
    double tileTRLatitude =  (_y+1) * _tileHeight;

    var theTile = GeoTile(GeoPoint(tileBLLongitude,tileBLLatitude),GeoPoint(tileTRLongitude,tileTRLatitude));
    return theTile;
  }


  bool moveNext() {

    if(!_isInitialized)
    {
      _isInitialized = true;
      _resetX();
      _resetY();

      if(_xNeedsRestart() || _yNeedsRestart())
        return false;

    }else {

      if(_xNeedsRestart())
        return false;

      _advanceY();
      if(_yNeedsRestart())
      {
        _advanceX();

        if(_xNeedsRestart())
          return false;

        _resetY();
      }
    }

    return true;
  }

}