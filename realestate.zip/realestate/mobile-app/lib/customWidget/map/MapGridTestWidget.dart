


import 'package:flutter/material.dart';
import 'package:realestate_app/customWidget/general/Utils.dart';
import 'package:realestate_app/customWidget/blocModelProvider/ModelProvidedState.dart';
import 'package:realestate_app/customWidget/map/GeoPoint.dart';
import 'package:realestate_app/customWidget/map/GeoTile.dart';

import 'GeoCoordinationLoader.dart';

class MapGridTestWidget extends StatefulWidget
{
  createState() => _MapGridTestWidgetState();
}

class _MapGridTestWidgetState extends ModelProvidedState<MapGridTestWidget,GeoCoordinationLoader> {

  var numberOnTop = -1;

  _MapGridTestWidgetState()
  {
    showLoadingAnimationPreventingTouchWhileLoading = false;
  }

  buildContent(context)
  {
    return Stack(
      children: [
        createButtons(context),

        if(numberOnTop > 0)
          Align(child: Container(color: Colors.brown,width: 100,height: 100,child: Text("$numberOnTop"),),)
      ],
    );
  }

  void eventReceived(String eventName,data) {

    switch(eventName)
    {
      case GeoCoordinationLoader.CurrentPageCoordinatesWereFetchedEvent :
        numberOnTop = -1;
        setState(() {});
        break;
      case GeoCoordinationLoader.CurrentPageMarkersCountWasFetchedDueToThresholdReachEvent :
        numberOnTop = data;
        setState(() {});
        break;
      case GeoCoordinationLoader.SomethingWentWrongEvent :
        setState(() {});
        break;
    }

  }

  Widget createButtons(context)
  {
    var shapes = <Widget>[];
    var width = percentageOfDeviceWidth(context, 1);
    var height = percentageOfDeviceHeight(context,1);

    var widthPieces = 360 / model.tileWidth;
    var heightPieces = 180 / model.tileHeight;

    var pieceWidth = (width ~/ widthPieces);
    var pieceHeight = (height ~/ heightPieces);

    for(int x = 0 ; x< widthPieces ; x++)
      for(int y = 0 ; y< heightPieces ; y++)
      {
        var tileLeft = ((x  *  model.tileWidth) - 180)  ;
        var tileBottom = -((y * model.tileHeight) - 90) - model.tileHeight;
        var tileTop = tileBottom + model.tileHeight;
        var tileRight = tileLeft + model.tileWidth;

        var tile = GeoTile(GeoPoint(tileLeft,tileBottom), GeoPoint(tileRight,tileTop));
        var tileData = model.getTileCachedData(tile);

        shapes.add(Positioned(key: ObjectKey("$x-$y"),left: x*pieceWidth.toDouble(),top: y*pieceHeight.toDouble(),
          child: GestureDetector(
              onTap: (){


                print("$tileLeft $tileBottom");

                model.loadPage(
                    tileLeft.toDouble(),
                    tileBottom.toDouble(),
                    tileLeft.toDouble() + 4*model.tileWidth,
                    tileBottom.toDouble() + 4*model.tileHeight
                );


              },
              child: Stack(
                children: [
                  Container(
                    color: (tileData == null)?Colors.redAccent:Colors.green
                    ,width: pieceWidth.toDouble()-1,height: pieceHeight.toDouble()-1,),

                  if(tileData != null && tileData.length>0)
                    Text("${tileData.length}",style: TextStyle(fontSize: 7,backgroundColor: Colors.green),)
                ],
              )),));
      }



    return Column(
      children: [

        Container(
            width: width.toDouble(),
            height: height.toDouble(),
            child: Stack(children: shapes,)),
      ],
    );
  }

}