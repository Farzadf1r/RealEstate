

class GeoPoint
{
  double get longitude => _longitude;
  double _longitude;
  double get latitude => _latitude;
  double _latitude;

  GeoPoint(double lon,double lat)
  {
    if(lat>90)
      _latitude = 90;
    else if(lat< -90)
      _latitude = -90;
    else
      _latitude = lat;


    if(lon>180)
      _longitude = 180;
    else if(lon< -180)
      _longitude = -180;
    else
      _longitude = lon;
  }

  toString() => '{lon: $longitude, lat: $latitude}';
}