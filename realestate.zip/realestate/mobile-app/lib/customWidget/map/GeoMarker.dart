

import 'package:realestate_app/customWidget/map/GeoPoint.dart';

class GeoMarker{
  final String id;
  final GeoPoint point;

  GeoMarker(this.id,this.point);
}
