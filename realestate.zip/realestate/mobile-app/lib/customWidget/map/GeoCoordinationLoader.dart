

import 'package:realestate_app/customWidget/general/Utils.dart';
import 'package:realestate_app/customWidget/blocModelProvider/BLoCModelBase.dart';
import 'package:realestate_app/customWidget/map/GeoBoundary.dart';
import 'package:realestate_app/customWidget/map/GeoPoint.dart';
import 'package:realestate_app/model/entity/PropertyAd.dart';


import '../../model/ServerGateway.dart';
import 'GeoMarker.dart';
import 'GeoTile.dart';




class GeoCoordinationLoader extends BLoCModelBase
{
  static const PropertyAdDetailsWasFetchedEvent = "PropertyAdDetailsWasFetchedEvent";
  static const CurrentPageCoordinatesWereFetchedEvent = "CurrentPageCoordinatesWereFetchedEvent";
  static const CurrentPageMarkersCountWasFetchedDueToThresholdReachEvent = "CurrentPageMarkersCountWasFetchedEvent";
  static const SomethingWentWrongEvent = "SomethingWentWrongEvent";
  
  final double tileWidth = 1;
  final double tileHeight = 180;
  final int _dataCountThreshold = 500;
  final Map<String,List<GeoMarker>> _loadedTiles = {};
  final List<GeoBoundary> _downloadedBoundaries = [];
  GeoBoundary _pendingRequest ;
  GeoBoundary _lastRequest ;
  GeoBoundary _acceptableBoundary;

  bool get hasDownloadedAnything => _downloadedBoundaries.isNotEmpty;
  double get minDownloadedLongitude => _downloadedBoundaries.min((e) => e.bottomLeftTile.bottomLeft.longitude).bottomLeftTile.bottomLeft.longitude;
  double get maxDownloadedLongitude => _downloadedBoundaries.max((e) => e.topRightTile.topRight.longitude).topRightTile.topRight.longitude;
  double get minDownloadedLatitude => _downloadedBoundaries.min((e) => e.bottomLeftTile.bottomLeft.latitude).bottomLeftTile.bottomLeft.latitude;
  double get maxDownloadedLatitude => _downloadedBoundaries.max((e) => e.topRightTile.topRight.latitude).topRightTile.topRight.latitude;


  GeoCoordinationLoader()
  {
    _acceptableBoundary = GeoBoundary(GeoPoint(-170, 40), GeoPoint(-50, 80),tileWidth,tileHeight);
    _lastRequest = GeoBoundary(GeoPoint(-180, -90), GeoPoint(180, 90),tileWidth,tileHeight);
    createStream(PropertyAdDetailsWasFetchedEvent);
    createStream(CurrentPageCoordinatesWereFetchedEvent);
    createStream(CurrentPageMarkersCountWasFetchedDueToThresholdReachEvent);
    createStream(SomethingWentWrongEvent);
  }

  bool _cameraHasMovedMoreThanMovementThreshold(GeoBoundary boundary)
  {
    var differ = _lastRequest.differFromAtLeast(boundary,boundary.minLineWidthWithingBoundary*0.05);

    if(differ)
      _lastRequest = boundary;

    return differ;
  }


  var _propertyIsLoading = false;
  void loadPropertyDetails(String id) {

   // print(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> load property $id $_propertyIsLoading");
    if(_propertyIsLoading)
      return;

    _propertyIsLoading = true;
    broadcastToStream(BLoCModelBase.IsLoadingEvent, true);

    Future<PropertyAd> result = ServerGateway.instance().fetchAdDetails(id);
    result.then((value) {
    //  print("@@@@@@@@@@@@2222load succeede ");
      _propertyIsLoading = false;
      broadcastToStream(BLoCModelBase.IsLoadingEvent, false);
      broadcastToStream(PropertyAdDetailsWasFetchedEvent,value);

    }, onError: (e) {
    //  print("@@@@@@@@@@@@@@@@@@load failed :::::${(e as UnexpectedResponseCode).message}");
      _propertyIsLoading = false;
      broadcastToStream(BLoCModelBase.IsLoadingEvent, false);
      broadcastToStream(SomethingWentWrongEvent,e);
    });
  }




  void loadPage(double blLongitude,double blLatitude,double trLongitude,double trLatitude,{bool forceLoad = false})
  {
    var boundary = GeoBoundary(GeoPoint(blLongitude,blLatitude),GeoPoint(trLongitude,trLatitude), tileWidth, tileHeight,acceptableRange: _acceptableBoundary);

    if(!_cameraHasMovedMoreThanMovementThreshold( boundary) && !forceLoad)
      return;

    var doWeHaveInCache = _doWeHaveAllNeededTilesInTheCache(boundary);

    if(doWeHaveInCache)
      _actBasedOnLoadPageFuture(_getMarkerDataWithinExactRange(boundary),false);
    else if(isLoading)
    {
      _pendingRequest = boundary;
      return;
    }else
      _actBasedOnLoadPageFuture(_downloadAndReturnMarkerWithinExactRange(boundary),true);
  }

  _actBasedOnLoadPageFuture(Future<List<GeoMarker>> result, bool handleLoadingStuff)
  {

    if(handleLoadingStuff)
      broadcastToStream(BLoCModelBase.IsLoadingEvent, true);

    result.then((value) {

      if(handleLoadingStuff)
      {
        broadcastToStream(BLoCModelBase.IsLoadingEvent, false);
        _issuePendingRequestIfAny();
      }

      broadcastToStream(CurrentPageCoordinatesWereFetchedEvent,value);

    }, onError: (e) {

      if(handleLoadingStuff)
      {
        broadcastToStream(BLoCModelBase.IsLoadingEvent, false);
        _issuePendingRequestIfAny();
      }

      if(e is GivenCoordinatesHaveDataBeyondThreshold)
        broadcastToStream(CurrentPageMarkersCountWasFetchedDueToThresholdReachEvent,e.dataCount);
      else
        broadcastToStream(SomethingWentWrongEvent,e);
    });
  }

  void _issuePendingRequestIfAny() {

    if(_pendingRequest == null)
      return;
    
    loadPage(
      _pendingRequest.bottomLeft.longitude,
      _pendingRequest.bottomLeft.latitude,
      _pendingRequest.topRight.longitude,
      _pendingRequest.topRight.latitude,
    );
    _pendingRequest = null;
  }

  bool _doWeHaveAllNeededTilesInTheCache(GeoBoundary boundary)
  {
    int start = currentTimeMillis;
    var iteratedOver = 0;
   // print("iteration over ${boundary.bottomLeftTile} - ${boundary.topRightTile}");
    var result = boundary.iterableOverAllTilesWithinInclusiveInclusive.every((GeoTile tile){
    //  print("iterating $tile");
      iteratedOver++;
      return  tileDataIsCached(tile);
    });
    //printTimeSince(start,message: "_doWeHaveAllNeededTilesInTheCache $iteratedOver $result");
    return result;
  }

  bool tileDataIsNotCached(GeoTile tile) => !tileDataIsCached(tile);
  bool tileDataIsCached(GeoTile tile) {
    return _downloadedBoundaries.any((b) =>
      b.bottomLeftTile.bottomLeft.longitude<= tile.bottomLeft.longitude &&
      b.bottomLeftTile.bottomLeft.latitude<= tile.bottomLeft.latitude &&
      b.topRightTile.bottomLeft.latitude >= tile.bottomLeft.latitude &&
      b.topRightTile.bottomLeft.longitude >= tile.bottomLeft.longitude
    );
  }

  List<GeoMarker> getTileCachedData(GeoTile tile)
  {
    var markers = _loadedTiles[tile.id];
    if(markers != null)
      return markers;

    return [];
  }

  Future<List<GeoMarker>> _downloadAndReturnMarkerWithinExactRange(GeoBoundary boundary) async{

    await _downloadAndCacheMarkerDataWithinRange(boundary);
    return _getMarkerDataWithinExactRange(boundary);
  }

  Future<List<GeoMarker>> _getMarkerDataWithinExactRange(GeoBoundary boundary) async
  {
    //print("was asked to load (cache=)  ${boundary.bottomLeftTile}  -   ${boundary.topRightTile} - ${boundary.bottomLeft} - ${boundary.topRight}");

    var countSoFar = 0;
    var dataSoFar = <GeoMarker>[];

    int start = currentTimeMillis;

    boundary.iterableOverAllTilesWithinInclusiveInclusive.forEach((GeoTile tile){
      var tileData = getTileCachedData(tile) ;

      if(tileData.isEmpty)
        return;

      if(countSoFar > _dataCountThreshold)
        countSoFar+=tileData.count((e)=>boundary.contains(e.point));
      else {
        var interestingDataWithinTile = tileData.where((e)=>boundary.contains(e.point));
        countSoFar+=interestingDataWithinTile.length;
        dataSoFar.addAll(interestingDataWithinTile);
      }
    });


   // printTimeSince(start,message: "_getMarkerDataWithinExactRange");
    
    if(countSoFar > _dataCountThreshold)
      throw GivenCoordinatesHaveDataBeyondThreshold(countSoFar);

    return dataSoFar;
  }




  Future<void> _downloadAndCacheMarkerDataWithinRange(GeoBoundary boundary) async{

    boundary = boundary.withAddedMargin(0.2,acceptableRange: _acceptableBoundary);

    var minLon = boundary.bottomLeftTile.bottomLeft.longitude;
    var maxLon = boundary.topRightTile.topRight.longitude;
    var minLat = boundary.bottomLeftTile.bottomLeft.latitude;
    var maxLat = boundary.topRightTile.topRight.latitude;

    if(hasDownloadedAnything)
    {
      var maxDLon = maxDownloadedLongitude;
      var minDLon = minDownloadedLongitude;

      if(minLon< minDLon && maxLon > maxDLon) {}
      else if(minLon < minDLon)
        maxLon = minDLon;
      else
        minLon = maxDLon;
    }


    var start = currentTimeMillis;

    print("going to download....");
    var beforeDownloadTime = currentTimeMillis;
    final result =await ServerGateway.instance().fetchAdsCoordinatesInThisRange(minLon, minLat, maxLon, maxLat);
    printTimeSince(beforeDownloadTime,message: "Downloading Geo Data");

   printTimeSince(start,message: "fetch from server ${result.length} - ${boundary.bottomLeftTile} - ${boundary.topRightTile}");

   start = currentTimeMillis;

    var addedThisTime = 0;

    var beforeCachingDownloadedGeoTime = currentTimeMillis;
    boundary.iterableOverAllTilesWithinInclusiveInclusive.forEach((GeoTile tile) {

      if (tileDataIsNotCached(tile)) {
        var data = <GeoMarker>[];

        for (GeoMarker r in result)
        {
          if (tile.contains(r.point))
            data.add(r);
        }

        if(data.isNotEmpty)
          _loadedTiles[tile.id] = data;

        addedThisTime += data.length;
      }
    });


    printTimeSince(start,message: "distribute downloaded data to tiles.all tiles = ${_loadedTiles.length}");
    _downloadedBoundaries.add(boundary);


    printTimeSince(beforeCachingDownloadedGeoTime,message: "Caching Downloaded Geo Time");
    print("added this time $addedThisTime");
  }

}