import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/physics.dart';
import 'package:realestate_app/customWidget/general/Toast.dart';
import 'package:realestate_app/customWidget/general/Utils.dart';
import 'package:realestate_app/customWidget/Util.dart';
import 'package:realestate_app/customWidget/blocModelProvider/BLoCModelBase.dart';
import 'package:realestate_app/customWidget/blocModelProvider/ModelProvidedState.dart';

import 'package:pull_to_refresh/pull_to_refresh.dart';
import 'package:realestate_app/customWidget/pagedListView/PageResult.dart';

import 'PagedContentModel.dart';


typedef PagedListViewItemBuilder<T> = Widget Function(
    BuildContext context, int overallPosition, T itemDate);

typedef FetchNextPageHandler<T> = Future<PageResult<T>> Function(int nextPageIndex,PagedContentModel<T> contentSoFar) ;

class PagedListView<T> extends StatefulWidget 
{
  final String contentDescription;
  final PagedListViewItemBuilder<T> builder;
  final  bool enableBottomPullToRefresh;

  PagedListView(this.contentDescription, this.builder,{this.enableBottomPullToRefresh = false}):super();

  createState() => PagedListViewState<T>();
}

class PagedListViewState<T> extends ModelProvidedState<PagedListView<T>, PagedContentModel<T>> {
  String get modelId => widget.contentDescription;

  ScrollController _scrollController = ScrollController();
  RefreshController _refreshController = RefreshController(initialRefresh: false);


  initState() {
    super.initState();
    _scrollController.addListener(_scrollChanged);

    if(model.totalFetched == 0)
      model.loadMore();
  }

  eventReceived(String event, data) {

    switch (event) {
      case PagedContentModel.NextPageFetchedEvent:
          _refreshController.refreshCompleted();
          setState(() {});

          WidgetsBinding.instance.addPostFrameCallback((_) {
            _scrollChanged();
          });
          break;


      case PagedContentModel.NextPageFetchErrorEvent:
        _refreshController.refreshCompleted();
        toast(data, context);
        break;

      case BLoCModelBase.IsLoadingEvent:
        _refreshController.loadComplete();
        break;
    }
  }

  _scrollChanged(){

    if(!_scrollController.hasClients)
        return null;

    double maxScroll = _scrollController.position.maxScrollExtent;
    double currentScroll = _scrollController.position.pixels;
    double delta = 100.0;

    if (maxScroll - currentScroll <= delta) model.loadMore();
  }

  buildContent(context) {

    return RefreshConfiguration(
      headerBuilder: () => WaterDropMaterialHeader(),
      footerBuilder: () => ClassicFooter(
        loadStyle: LoadStyle.ShowWhenLoading,
      ),
      headerTriggerDistance: 80.0,
      springDescription:
          SpringDescription(stiffness: 170, damping: 16, mass: 1.9),
      maxOverScrollExtent: 100,
      maxUnderScrollExtent: 0,
      enableScrollWhenRefreshCompleted: true,
      enableLoadingWhenFailed: true,
      hideFooterWhenNotFull: false,
      enableBallisticLoad: true,
      child: SmartRefresher(
          controller: _refreshController,
          enablePullUp: widget.enableBottomPullToRefresh,
          onLoading: () {
            model.checkForNewPageAgain();
          },
          onRefresh: () {
            model.loadFromStart();
          },
          child: model.isEmpty && !model.isLoading
              ? _createEmptyWidget()
              : _createListView()),
    );
  }

  _createEmptyWidget() =>Center(child: halveticaText("Empty List",),);

  ListView _createListView() {
    return ListView.builder(
      controller: _scrollController,
      itemCount: model.totalFetched,
      itemBuilder: (BuildContext context, int index) =>
          widget.builder(context, index, model.contentFetchedSoFar[index]),
    );
  }
}
