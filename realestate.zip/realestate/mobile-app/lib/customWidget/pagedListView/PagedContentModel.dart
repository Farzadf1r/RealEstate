
import 'package:realestate_app/customWidget/blocModelProvider/BLoCModelBase.dart';
import 'package:realestate_app/customWidget/pagedListView/PageResult.dart';

import 'PagedListView.dart';

class PagedContentModel<T> extends BLoCModelBase {
  static const String NextPageFetchedEvent = "NextPageFetchedEvent";
  static const String NextPageFetchErrorEvent = "NextPageFetchErrorEvent";

  bool _hasPendingLoadFromStart = false;

  FetchNextPageHandler<T> _fetchNextPageHandler;
  final int pageSize;
  final String contentDescription;
  final bool reloadWhenItemsCountChanges;

  int _currentPageIndex = -1;
  bool _lastPageReached = false;
  List<T> _contentFetchedSoFar = [];
  PageResult<T> _lastPage;

  int get currentPageIndex => _currentPageIndex;
  bool get lastPageReached=> _lastPageReached;
  List<T> get contentFetchedSoFar => _contentFetchedSoFar.getRange(0, _contentFetchedSoFar.length).toList();
  int get totalFetched => _contentFetchedSoFar.length;
  bool get isEmpty => totalFetched == 0;

  PagedContentModel(this.pageSize,this.contentDescription,this._fetchNextPageHandler,{this.reloadWhenItemsCountChanges = true}) {
    createStream(NextPageFetchedEvent);
    createStream(NextPageFetchErrorEvent);

    if(pageSize<=0)
      throw Exception("page size should be > 0");
  }
  
  void setFetchNextPageHandler(FetchNextPageHandler<T> handler)
  {
    if(_fetchNextPageHandler == null)
      this._fetchNextPageHandler = handler;
    else
      throw Exception("you cannot reset next page hadler after it has been set!");
  }

  Future<PageResult<T>> _fetchNextPage(int pageIndex) => _fetchNextPageHandler(currentPageIndex+1,this);

  void loadMore() {

    if(isDisposed)
      return;


    if(_lastPageReached)
      return;

    if(isLoading)
      return;


    broadcastToStream(BLoCModelBase.IsLoadingEvent, true);

    var nextPage = _fetchNextPage(currentPageIndex + 1);
    nextPage.then((value) {


      try{broadcastToStream(BLoCModelBase.IsLoadingEvent, false);}catch(e){return;}

      if(value==null)
        throw Exception("retrieved page was null!");

      if(value.determineIfYouNeedReloadingDueToTotalItemsCountChangeSinceLastQuery(_lastPage) && reloadWhenItemsCountChanges) {
        loadFromStart();
        return;
      }

      if(value.isLessThanItShouldBe)
        throw Exception("only the last page can be partial $value");

      _lastPageReached = value.isLastPage;
      _lastPage = value;

      if(value.isNotEmpty) {
        _contentFetchedSoFar.addAll(value.result);
        _currentPageIndex++;
      }

      broadcastToStream(NextPageFetchedEvent, currentPageIndex);

    }, onError: (e,stackTrace) {
      broadcastToStream(BLoCModelBase.IsLoadingEvent, false);
      print(stackTrace);
      broadcastToStream(NextPageFetchErrorEvent,
          "Fetching Next Page Failed, Please Retry... $e");
    }).whenComplete((){
      if(_hasPendingLoadFromStart)
      {
        _hasPendingLoadFromStart = false;
        loadFromStart();
      }
    });
  }

  void loadFromStart() {
    if(isLoading) {
      _hasPendingLoadFromStart = true;
      return;
    }

    _lastPage = null;
    _currentPageIndex=-1;
    _lastPageReached = false;
    _contentFetchedSoFar =[];

    loadMore();
  }

  void checkForNewPageAgain() {
    if(isLoading)
      return;

    _lastPageReached = false;

    loadMore();
  }



  toString() {
    return 'PagedContentModel{pageSize: $pageSize, contentDescription: $contentDescription, currentPageIndex: $_currentPageIndex, lastPageReached: $_lastPageReached}';
  }
}
