


class PageResult<T>
{
  final int pageSize;
  final int pageIndex;
  final int _totalItemsCount;

  final List<T> result;


  int get totalItemsCount{
    if(!hasTotalItemsCount)
      throw Exception("the result does not have the total items count needed for calculations!");

    return _totalItemsCount;
  }

  bool get hasTotalItemsCount => _totalItemsCount>0;



  int get totalPagesCount {

    if(!hasTotalItemsCount)
      throw Exception("the result does not have the total items count needed for calculations!");

    return (_totalItemsCount / pageSize).ceil();
  }

  bool get isLastPage {

    if(hasTotalItemsCount)
      return pageIndex == totalPagesCount - 1 || totalPagesCount==0;
    else
      return isNotAFullPage;
  }


  bool get isNotLastPage=>!isLastPage;
  bool get isAFullPage => thisPageItemsCount == pageSize;
  bool get isNotAFullPage => !isAFullPage;
  bool get isEmpty => thisPageItemsCount == 0;
  bool get isNotEmpty => thisPageItemsCount > 0;
  int get thisPageItemsCount => result.length;

  bool get isLessThanItShouldBe{
    return (hasTotalItemsCount && isNotLastPage && isNotAFullPage);
  }

  PageResult(this.pageSize, this.pageIndex, this._totalItemsCount, this.result);



  bool determineIfYouNeedReloadingDueToTotalItemsCountChangeSinceLastQuery(PageResult<T> prevPageResult)
  {
    if(prevPageResult==null)
      return false;

    return (prevPageResult.hasTotalItemsCount && hasTotalItemsCount && prevPageResult._totalItemsCount!=_totalItemsCount);
  }

  toString() =>"""
  PageResult{
        pageSize: $pageSize, 
        pageIndex: $pageIndex, 
        totalItemsCount: $totalItemsCount
        thisPageItemsCount : $thisPageItemsCount,
        totalPagesCount : $totalPagesCount,
        isLastPage : $isLastPage,
        isAFullPage : $isAFullPage,
        isEmpty : $isEmpty,
  }""";

}