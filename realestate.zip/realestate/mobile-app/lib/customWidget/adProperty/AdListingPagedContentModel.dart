import 'package:flutter/cupertino.dart';
import 'package:realestate_app/customWidget/pagedListView/PagedContentModel.dart';
import 'package:realestate_app/model/ServerGateway.dart';
import 'package:realestate_app/model/entity/PropertyAd.dart';
import 'package:realestate_app/model/entity/PropertyAdSearchFilter.dart';

class AdListingPagedContentModel extends PagedContentModel<PropertyAd> {
  ValueNotifier<PropertyAdSearchFilter> _searchFilter;

  AdListingPagedContentModel(
      int pageSize, String contentDescription,  this._searchFilter)
      : super(pageSize, contentDescription,null)
  {
    setFetchNextPageHandler((int nextPageIndex, PagedContentModel<PropertyAd> contentSoFar) {
      return ServerGateway.instance()
          .fetchAds(nextPageIndex, pageSize, _searchFilter.value);
    });

    _searchFilter.addListener(() {
      loadFromStart();
    });
  }
}
