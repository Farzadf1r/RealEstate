import 'dart:io';

import 'package:realestate_app/customWidget/blocModelProvider/BLoCModelBase.dart';
import 'package:realestate_app/model/ServerGateway.dart';
import 'package:realestate_app/model/entity/PropertyAd.dart';
import 'package:realestate_app/model/exception/ConnectionToBackendFailed.dart';
import 'package:realestate_app/model/exception/UserIsAnonymous.dart';

class PreLoadedPropertyDetailsModel extends BLoCModelBase {
  static const String favoriteToggleErrorMessagesEvent = "favoriteToggleErrorMessagesEvent";
  static const String userWasAnonymousErrorMessagesEvent = "userWasAnonymousMessagesEvent";

  PropertyAd _propertyAd;


  PropertyAd get ad => _propertyAd;

  
  PreLoadedPropertyDetailsModel(PropertyAd ad) {
    createStream(favoriteToggleErrorMessagesEvent);
    createStream(userWasAnonymousErrorMessagesEvent);
    _propertyAd = ad;
  }



  void invertFavoriteStatus() {

    if(isLoading)
      return;

    broadcastToStream(BLoCModelBase.IsLoadingEvent, true);

    var result;
    if (ad.isFavorite)
      result = ServerGateway.instance().untagAsFavorite(ad.id);
    else
      result = ServerGateway.instance().tagAsFavorite(ad.id);

    result.then((value) {
      ad.isFavorite = ! ad.isFavorite;
      broadcastToStream(BLoCModelBase.IsLoadingEvent, false);
    }, onError: (e) {
      broadcastToStream(BLoCModelBase.IsLoadingEvent, false);

      if (e is ConnectionToBackendFailed)
        broadcastToStream(
            favoriteToggleErrorMessagesEvent, "Check Internet Connection");
      else if (e is UserIsAnonymous)
        broadcastToStream(
            userWasAnonymousErrorMessagesEvent, "user was anonymous");
      else
        broadcastToStream(
            favoriteToggleErrorMessagesEvent, "Something ain't right $e  ${e.runtimeType}");
    });
  }




  Future<File> loadImage(String url) {
    return ServerGateway.instance().loadImage(url);
  }

  updateBasedOn(PropertyAd changedModel) {
    _propertyAd.isFavorite = changedModel.isFavorite;
  }

}
