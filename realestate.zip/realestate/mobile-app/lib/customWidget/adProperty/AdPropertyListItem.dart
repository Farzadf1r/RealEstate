import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:realestate_app/customWidget/general/FutureWidget.dart';
import 'package:realestate_app/customWidget/general/Toast.dart';
import 'package:realestate_app/customWidget/general/Utils.dart';
import 'package:realestate_app/customWidget/blocModelProvider/ModelProvidedState.dart';
import 'package:realestate_app/model/entity/PropertyAd.dart';
import 'package:realestate_app/pages/Router.dart';
import 'package:flutter_svg/svg.dart';

import 'package:realestate_app/model/entity/Status.dart';
import 'package:realestate_app/pages/animation/animatedLoadScreen.dart';

import 'package:realestate_app/customWidget/Util.dart';
import 'PreLoadedPropertyDetailsModel.dart';

class AdPropertyListItem extends StatefulWidget {
  final PropertyAd ad;

  AdPropertyListItem(this.ad) : super();


  createState() => AdPropertyListItemState();
}

class AdPropertyListItemState extends ModelProvidedState<AdPropertyListItem, PreLoadedPropertyDetailsModel> {

  String get modelId => widget.ad.id;
  Object get modelArgument => widget.ad;

  AdPropertyListItemState();


  void eventReceived(String eventName, data) {
    switch (eventName) {
      case PreLoadedPropertyDetailsModel.favoriteToggleErrorMessagesEvent:
        toast(data, context);
        break;
      case PreLoadedPropertyDetailsModel.userWasAnonymousErrorMessagesEvent:
        bringUpLoginDialog(context);
    }
  }

  buildContent(BuildContext context) => _createItemAsRaisedButton(context);

  _createItemAsRaisedButton(context) {
    return SizedBox(
      width: double.infinity,
      child: ButtonTheme(
        minWidth: 0,
        height: 0,
        materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
        padding: EdgeInsets.zero,
        child: RaisedButton(
          clipBehavior: Clip.antiAlias,
          color: Colors.grey[100],
          onPressed: () {
            _goToDetailsPage();
          },
          elevation: 6.0,
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(14.0)),
          child: _createContentOfRaisedButton(),
        ),
      ),
    );
  }

  _goToDetailsPage() {
    showPropertyDetailsPage(context, model.ad,modelChangedCallback:(changedModel)=>model.updateBasedOn(changedModel)).then((value) {
      setState(() {});
    });
  }

  _createContentOfRaisedButton() {
    return Stack(
      children: [
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _createThumbnailAndFavButtonStack(),
            _createPriceText(model.ad.priceDecorated,padding: EdgeInsets.only(left: 10, top: 5)),
            _createAddressText(),
            SizedBox(height: 4),
            summary(),
            //_createSummaryText(),
            SizedBox(height: 8)
          ],
        ),

        if(model.ad.isSoldButNotConditionally)
          Positioned(child:_createSoldStatus()),


        Positioned(
          child: _createPropertyTypeText(),
          right: 10,
          bottom: 5,
        )
      ],
    );
  }

  _createSoldStatus()
  {
    return Padding(
      padding: const EdgeInsets.all(3.0),
      child: Container(
        width: 80,height: 80,
        child: Stack(fit: StackFit.expand,alignment: AlignmentDirectional.topStart,
          children: [
            svgAssetPicture("images/sold.svg",width: 80,height: 80,fit: BoxFit.contain,color: null),
            Transform.rotate(
              angle: -3.14/4,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.center,

                children: [
                  Spacer(flex: 4,),
                 halveticaBoldText(model.ad.status.name,color: Colors.white,fontSize: 9,),
                  SizedBox(height: 1,),
                  _createPriceText(model.ad.soldPriceDecorated,color: Colors.white,fontSize: 9),
                  Spacer(flex: 5,),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Stack _createThumbnailAndFavButtonStack() {
    return Stack(clipBehavior: Clip.none, children: [
      _createThumbnailWidget(),
      Positioned(right: 10, bottom: -10, child: _createFavoritesButton())
    ]);
  }

  _createFavoritesButton() {
    return createFavoritesButton(model.ad.isFavorite, () {
        model.invertFavoriteStatus();
      }, size: 20);}

  _createThumbnailWidget() {
    return FutureWidget(initialLoadingBoxHeight: percentageOfDeviceHeight(context, 0.3)
      ,touchInterceptorLoadingWrapperOnTopOfWidget: wrapItInAnimatedLoadingWidgetOnTopWhichInterceptsTouch,
      future: FutureValue(computation:()=>model.loadImage(model.ad.thumbnailUrl),key: model.ad.id),
      builder: (context, file) => Container(
        height: percentageOfDeviceHeight(context, 0.3),
        width: percentageOfDeviceWidth(context, 1),
        child: Image.file(
          file,
          fit: BoxFit.cover,
        ),
      ),
    );
  }

  _createPriceText(String price,{Color color = const Color(0xff0054a4),double fontSize = 17,EdgeInsetsGeometry padding = const EdgeInsets.all(0)}) => halveticaBoldText(
      price,
      color: color,
      fontSize: fontSize,
      padding: padding);

  _createAddressText() => halveticaText(model.ad.addressInDetail(includeTitle: false,separator: "  "),
      color: Colors.black,
      fontSize: 14,
      weight: FontWeight.w600,
      padding: EdgeInsets.only(left: 10, top: 4));

  _createSummaryText() => ptSansCaptionBoldText(
      "${model.ad.numBedrooms} Bedrooms | ${model.ad.numBathrooms} Bathrooms | ${model.ad.sqftConsideringRange} sqft",
      color: Colors.black,
      fontSize: 12,
      padding: EdgeInsets.only(left: 10, top: 4, bottom: 8));

  _createPropertyTypeText() => halveticaText(model.ad.propertyTypeAndStyleDescription,
      color: Colors.black, fontSize: 7.0, weight: FontWeight.bold);


  SvgPicture svgAssetPicture(String path,
      {String semantics = "", double width = 20, double height = 20, Color color = const Color(
          0xff505050) ,BoxFit fit=BoxFit.contain}) {
    return SvgPicture.asset(
      path,fit:fit,
      semanticsLabel: semantics,
      width: width,
      height: height,
      color: color,
    );
  }

  _bathroomIcon() => svgAssetPicture('images/bathtub.svg');
  _bedroomIcon() => svgAssetPicture('images/bedroom.svg',);
  _sqftIcon() => svgAssetPicture('images/house.svg',);

  _createSummaryTextBedroom() => ptSansCaptionBoldText(
      "${model.ad.bedroomCountDescription} ",
      color: Colors.black,
      fontSize: 12,
      padding: EdgeInsets.only(left: 10,right: 2)
  );

  _createSummaryTextBathroom() => ptSansCaptionBoldText(
      "    ${model.ad.bathroomCountDescription} ",
      color: Colors.black,
      fontSize: 12,
      padding: EdgeInsets.only(left: 3,right: 2));

  _createSummaryTextSqft() => ptSansCaptionBoldText(
      "   ${model.ad.sqftConsideringRange}",
      color: Colors.black,
      fontSize: 12,
      padding: EdgeInsets.only(left: 3,right: 2));

  Row summary(){
    return Row(
      crossAxisAlignment: CrossAxisAlignment.center,

      children: [

        if(model.ad.hasBedroomData)
          _createSummaryTextBedroom(),

        if(model.ad.hasBedroomData)
          _bedroomIcon(),

        if(model.ad.hasBathroomData)
          _createSummaryTextBathroom(),

        if(model.ad.hasBathroomData)
          _bathroomIcon(),

        if(model.ad.hasSQFTData)
          _createSummaryTextSqft(),

        if(model.ad.hasSQFTData)
          _sqftIcon()
      ],
    );
  }


}
