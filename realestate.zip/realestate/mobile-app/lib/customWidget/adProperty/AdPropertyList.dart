import 'package:flutter/cupertino.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:realestate_app/customWidget/adProperty/AdListingPagedContentModel.dart';
import 'package:realestate_app/customWidget/blocModelProvider/ModelProvider.dart';
import 'package:realestate_app/customWidget/pagedListView/PagedListView.dart';
import 'package:realestate_app/model/entity/PropertyAd.dart';
import 'package:realestate_app/model/entity/PropertyAdSearchFilter.dart';

import 'AdPropertyListItem.dart';

class AdPropertyList extends StatelessWidget {
  final ValueNotifier<PropertyAdSearchFilter> _searchFilter;
  final String contentDescription;

  AdPropertyList(this._searchFilter, this.contentDescription)
  {
    ModelProvider.instance.provideThisOneTimeAlternativeIfCreatorCouldNotCreate(contentDescription, ()=>
        AdListingPagedContentModel(10, contentDescription, _searchFilter));
  }

  build(BuildContext context) {
    return PagedListView<PropertyAd>(
        contentDescription,
        (context, overallPosition, PropertyAd ad) => Padding(
              padding: const EdgeInsets.all(8.0),
              child: AdPropertyListItem(ad),
            ));
  }
}
