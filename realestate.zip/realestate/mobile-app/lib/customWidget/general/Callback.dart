typedef Callback = void Function();
typedef ValueChangedCallback<T> = void Function(T);