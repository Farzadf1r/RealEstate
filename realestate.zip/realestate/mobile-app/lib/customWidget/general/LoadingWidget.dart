

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class LoadingWidget extends StatelessWidget
{
  const LoadingWidget();

  build(context) => CircularProgressIndicator(backgroundColor: Colors.blue,);
}